<center><img src="loading.gif" style="padding-top:100px"/></center>
<script>
window.location.href = "http://baicebu.com/trans2/apps/schedules.php";
</script>