<?php 

echo '["http://i.froala.com/assets/photo1.jpg","http://i.froala.com/assets/photo2.jpg","http://i.froala.com/assets/photo3.jpg","http://i.froala.com/assets/photo4.jpg","http://i.froala.com/assets/photo5.jpg","http://i.froala.com/assets/photo6.jpg","http://i.froala.com/assets/photo7.jpg","http://i.froala.com/assets/photo8.jpg","http://i.froala.com/assets/photo9.jpg","http://i.froala.com/assets/photo10.jpg"]';

?>